<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bukus', function (Blueprint $table) {
            // Kolom id: bigint(20), UNSIGNED, AUTO_INCREMENT, Primary Key
            $table->id();

            $table->char('kode', 12);

            $table->string('judul');

            $table->string('penulis');

            $table->string('penerbit');

            $table->string('tahun_terbit');

            $table->string('stok');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bukus');
    }
};
