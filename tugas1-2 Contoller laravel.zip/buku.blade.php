<!DOCTYPE html>
<html>
<head>
    <title>Koleksi Buku</title>
</head>
<body>

    <h1>Koleksi Buku Perpustakaan</h1>

    <ul>
        @foreach ($buku as $judul => $pengarang)
            <li>
                <strong>{{ $judul }}</strong> - {{ $pengarang }}
            </li>
        @endforeach
    </ul>

</body>
</html>
