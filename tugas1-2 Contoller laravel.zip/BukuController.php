<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BukuController extends Controller
{
    public function index()
    {
        return view('welcome');
    }

    public function tampil()
    {
        $buku = [
            'Laskar Pelangi' => 'karya Andrea Hirata.',
            'Bumi Manusia' => 'karya Pramoedya Ananta Toer.',
            'Laut Bercerita' => 'karya Leila S. Chudori.',
            'Cantik Itu Luka' => 'karya Eka Kurniawan.',
            'Ronggeng Dukuh Paruk' => 'karya Eka Kurniawan.'
        ];

        return view('buku')->with('buku', $buku);
    }
}
