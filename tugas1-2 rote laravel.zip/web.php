<?php

use Illuminate\Support\Facades\Route;

Route::get('/profil/{Ali}/{XI_RPL}/{Orang_Sukses}', function ($nama, $kelas, $citaCita) {
    return "<h1>Halo, nama saya $nama, saya dari kelas $kelas, dan cita-cita saya adalah menjadi $citaCita.</h1>";
});
